#ifndef _TEST_NET_LOOP_H
#define _TEST_NET_LOOP_H

void test_net_loop(void);

#endif
