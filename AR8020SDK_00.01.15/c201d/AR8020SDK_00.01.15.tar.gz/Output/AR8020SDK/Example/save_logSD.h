#ifndef _SAVE_LOGSD_H
#define _SAVE_LOGSD_H

#include "hal.h"
#include "debuglog.h"

void dlog_output_SD(char* buf, unsigned int bytes);

#endif
