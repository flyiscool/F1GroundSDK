#ifndef __TEST_LWIP_TCPIP_
#define __TEST_LWIP_TCPIP_

#ifdef __cplusplus
extern "C"
{
#endif

void test_tcpip( void );


#ifdef __cplusplus
}
#endif 

#endif