#ifndef __TEST_HDMI_H__
#define __TEST_HDMI_H__

#ifdef __cplusplus
extern "C"
{
#endif


void HDMI_RX_VideoCallbakSample(void *p);


#ifdef __cplusplus
}
#endif

#endif

