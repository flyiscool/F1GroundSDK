#ifndef __BB_REPLY_PC_H
#define __BB_REPLY_PC_H


#include "hal_usb_host.h"

void BB_ReplyPcHandler(void *p);

#endif
