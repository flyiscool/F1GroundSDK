#ifndef _TEST_OS_MUTEX_H
#define _TEST_OS_MUTEX_H

#ifdef __cplusplus
extern "C"
{
#endif


int test_os_mutex(void);


#ifdef __cplusplus
}
#endif

#endif
