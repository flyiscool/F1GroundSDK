#ifndef _TEST_OS_TIMER_H
#define _TEST_OS_TIMER_H

#ifdef __cplusplus
extern "C"
{
#endif


void test_os_timer(void);


#ifdef __cplusplus
}
#endif

#endif
