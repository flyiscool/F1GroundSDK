#ifndef __TEST_USR_UART__
#define __TEST_USR_UART__

#ifdef __cplusplus
extern "C"
{
#endif


void Usr_Uart_Task(int send);

#ifdef __cplusplus
}
#endif

#endif

