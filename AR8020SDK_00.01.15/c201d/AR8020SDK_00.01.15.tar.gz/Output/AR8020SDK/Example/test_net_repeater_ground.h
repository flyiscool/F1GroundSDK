#ifndef __TEST_NET_REPEATER_GROUND_H__
#define __TEST_NET_REPEATER_GROUND_H__

#ifdef __cplusplus
extern "C"
{
#endif


void command_TestNetRepeaterGnd( void );


#ifdef __cplusplus
}
#endif 

#endif

