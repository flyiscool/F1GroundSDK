#ifndef _TEST_OS_SEMAPHORE_H
#define _TEST_OS_SEMAPHORE_H

#ifdef __cplusplus
extern "C"
{
#endif


int test_os_semaphore(void);


#ifdef __cplusplus
}
#endif 

#endif
