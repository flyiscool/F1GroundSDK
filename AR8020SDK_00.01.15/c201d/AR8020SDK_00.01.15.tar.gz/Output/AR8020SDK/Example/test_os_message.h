#ifndef _TEST_OS_MESSAGE_H
#define _TEST_OS_MESSAGE_H

#ifdef __cplusplus
extern "C"
{
#endif


void test_os_message(void);


#ifdef __cplusplus
}
#endif 

#endif
