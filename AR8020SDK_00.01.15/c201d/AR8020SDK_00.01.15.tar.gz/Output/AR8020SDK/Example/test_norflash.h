#ifndef TEST_NORFLASH_H
#define TEST_NORFLASH_H

#ifdef __cplusplus
extern "C"
{
#endif

void command_testNorFlash(char* start_addr_str, char* size_str, char* val_str);


#ifdef __cplusplus
}
#endif

#endif

