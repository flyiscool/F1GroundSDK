#ifndef TEST_SYSEVENT_PERF_H
#define TEST_SYSEVENT_PERF_H

#ifdef __cplusplus
extern "C"
{
#endif


void EVENT_PerformanceTestInit(void);

void EVENT_PerformanceCheckCnt(void);

void EVENT_PerformancePrintCnt(void);


#ifdef __cplusplus
}
#endif 

#endif
