#ifndef __TEST_RTC_H__
#define __TEST_RTC_H__

#ifdef __cplusplus
extern "C"
{
#endif

DWORD get_fattime (void);

#ifdef __cplusplus
}
#endif 


#endif

