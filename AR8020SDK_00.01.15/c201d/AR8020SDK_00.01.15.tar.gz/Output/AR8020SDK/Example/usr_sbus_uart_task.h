#ifndef __TEST_SBUS_UART__
#define __TEST_SBUS_UART__

#ifdef __cplusplus
extern "C"
{
#endif


void usr_bypass_sbus_uart_task(uint8_t dev_type);


uint8_t get_fac_spi_num(void);



#ifdef __cplusplus
}
#endif

#endif

