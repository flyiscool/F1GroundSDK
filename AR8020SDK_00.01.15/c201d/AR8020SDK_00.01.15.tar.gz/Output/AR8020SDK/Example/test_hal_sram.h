#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "debuglog.h"

void command_GetSramReceivedDataSize(void);

