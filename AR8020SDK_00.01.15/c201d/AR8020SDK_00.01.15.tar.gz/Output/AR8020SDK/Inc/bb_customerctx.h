#ifndef __BB_CUSTOMER_CTX_H_
#define __BB_CUSTOMER_CTX_H_


#include "boardParameters.h"


typedef struct
{
    uint8_t     itHopMode;
    uint8_t     rcHopMode;
    uint8_t     qam_skip_mode;
} STRU_CUSTOMER_CFG;


#endif
