#ifndef FPU_H
#define FPU_H

void FPU_AccessEnable(void);
void FPU_AccessDisable(void);

#endif

