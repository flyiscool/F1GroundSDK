#ifndef __ENC_CUSTOMER_CTX_H_
#define __ENC_CUSTOMER_CTX_H_


#include "boardParameters.h"


typedef struct
{
    uint8_t     u8_encHdmiDvpPolarity;
    uint8_t     u8_encMipiPolarity;
} STRU_ENC_CUSTOMER_CFG;


#endif
